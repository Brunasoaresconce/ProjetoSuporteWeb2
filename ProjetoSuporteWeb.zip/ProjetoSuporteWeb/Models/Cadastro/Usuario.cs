﻿namespace ProjetoSuporteWeb.Models.Cadastro
{
    public class Usuario
    {
        public int id { get; set; }
        public string nm_usuario { get; set; }
        public string senha { get; set; }
        public string status { get; set; }
    }

}
